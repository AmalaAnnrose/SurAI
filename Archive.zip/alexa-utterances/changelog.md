# 0.2.1

updated tap module to `6.1.1`


# 0.2.0

Added custom slot type support.